from flask import Flask, request, jsonify, render_template
import joblib
import re
import string
import nltk
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import VotingClassifier

# Download necessary NLTK resources
nltk.download('punkt')
nltk.download('stopwords')

# Load the pre-trained model and vectorizer
voting_model = joblib.load(r"C:\Users\Admin\Desktop\Project\3 FM 80+ Accuracy\FM3\GSA\gujarati_sentiment_model.pkl")
vectorizer = joblib.load(r"C:\Users\Admin\Desktop\Project\3 FM 80+ Accuracy\FM3\GSA\tfidf_vectorizer.pkl")

# Gujarati stopwords and preprocessing functions
gujarati_stopwords = [
    'આ', 'છે', 'અને', 'મા', 'ના', 'ને', 'થી', 'પર', 'વિશે', 'ના', 'સાથે', 'કિ', 'એ', 'તમારું', 'તમારા', 'તે', 'કરે', 'કરી', 'છે', 'માટે', 'માટે', 'ના', 'એ', 'પર', 'તે',
    'વાળા', 'આઠ', 'પણ', 'શું', 'કઈ', 'કે', 'જેમ', 'કેટલુ', 'કેટલી', 'કેવળ', 'આગળ', 'મારે', 'હવે', 'જ્યાં', 'કેવું', 'ક્યાં', 'આલટાની', 'ઘણો', 'વધુ', 'ઓછો', 'મોટું', 'ક્યારે',
    'કારણ', 'અન્ય', 'છ', 'છતાં', 'તટસ્થથ', 'કરવું', 'રહેશે', 'એવી', 'પછી', 'તેવા', 'માટે', 'કેવું', 'જ્યાં', 'નવું', 'પરિસ્થિથિતિ', 'વચ્ચે', 'ની', 'જોવા', 'તે', 'એક', 'જેવી', 'કે'
]

def gujarati_stem(word):
    suffixes = ['ો', 'ઓ', 'તા', 'તી', 'એ', 'માં', 'નો', 'ની', 'ને', 'વા', 'વું', 'તા']
    for suffix in suffixes:
        if word.endswith(suffix):
            word = word[:-len(suffix)]
            break
    return word

def gujarati_lemmatize(word):
    verb_endings = ['તા', 'તી', 'વું', 'વાનો', 'વાની']
    for ending in verb_endings:
        if word.endswith(ending):
            word = word[:-len(ending)] + "વું"
            break
    return word

def preprocess_text(text):
    words = word_tokenize(text)
    words = [word for word in words if word not in string.punctuation]
    words = [word for word in words if word not in gujarati_stopwords]
    words = [gujarati_stem(word) for word in words]
    words = [gujarati_lemmatize(word) for word in words]
    return ' '.join(words)

# Initialize Flask app
app = Flask(__name__)

# Home route - Display the frontend webpage
@app.route('/')
def home():
    return render_template('index.html')

# API route - Predict sentiment for given text
@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get the text from the request (from the frontend)
        text = request.form['text']
        
        if not text:
            return jsonify({'error': 'લેખન જરૂરી છે'}), 400

        # Preprocess the input text using the same preprocessing steps as in your project
        cleaned_text = preprocess_text(text)

        # Preprocess the input text using the vectorizer
        new_text_tfidf = vectorizer.transform([cleaned_text])
        
        # Make prediction using the loaded model
        prediction = voting_model.predict(new_text_tfidf)
        predicted_probs = voting_model.predict_proba(new_text_tfidf)
        
        # Mapping sentiment labels
        sentiment_mapping = {1: "સકારાત્મક", 2: "તટસ્થ", 0: "નકારાત્મક"}
        sentiment = sentiment_mapping[prediction[0]]
        confidence = max(predicted_probs[0]) * 100
        
        # Return the result as JSON to be used in frontend
        return jsonify({
            'sentiment': sentiment,
            'confidence': f"{confidence:.2f}%"
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# API route - Extract keywords from the given text
@app.route('/extract_keywords', methods=['POST'])
def extract_keywords():
    try:
        # Get the text from the request (from the frontend)
        text = request.form['text']
        
        if not text:
            return jsonify({'error': 'Text is required for keyword extraction.'}), 400
        
        # Preprocess the input text using the same preprocessing steps as in your project
        cleaned_text = preprocess_text(text)

        # Preprocess the input text using CountVectorizer for keyword extraction
        count_vectorizer = TfidfVectorizer(stop_words=gujarati_stopwords)
        words = count_vectorizer.fit_transform([cleaned_text])
        
        # Extract top words (keywords)
        keywords = count_vectorizer.get_feature_names_out()
        
        # Return the keywords
        return jsonify({'keywords': keywords.tolist()})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Run the app
if __name__ == "__main__":
    app.run(debug=True)
