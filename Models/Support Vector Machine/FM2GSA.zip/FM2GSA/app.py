from flask import Flask, request, jsonify, render_template
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
import re  # To use regular expressions for Gujarati character checking

# Load the pre-trained model and vectorizer
model = joblib.load(r"C:\Users\Admin\Desktop\MY_Pro\Project\3 FM 80+ Accuracy\FM2\FM2GSA\gujarati_sentiment_model.pkl")
vectorizer = joblib.load(r"C:\Users\Admin\Desktop\MY_Pro\Project\3 FM 80+ Accuracy\FM2\FM2GSA\tfidf_vectorizer.pkl")

# Mapping sentiment labels (for easier understanding of results)
sentiment_mapping = {1: "સકારાત્મક", 2: "તટસ્થ", 0: "નકારાત્મક"}

# Initialize Flask app
app = Flask(__name__)

# Function to check if the text is in Gujarati
def is_gujarati(text):
    # Regex to check if the text contains any Gujarati characters
    return bool(re.match(r'^[\u0A80-\u0AFF\s]+$', text))

# Home route - Display the frontend webpage
@app.route('/')
def home():
    return render_template('index.html')

# API route - Predict sentiment for given text
@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get the text from the request (from the frontend)
        text = request.form['text']
        
        if not text:
            return jsonify({'error': 'લેખન જરૂરી છે'}), 400

        # Check if the text is in Gujarati
        if not is_gujarati(text):
            return jsonify({'error': 'માત્ર ગુજરાતી લખાણ લખો'}), 400
        
        # Preprocess the input text using the same vectorizer
        new_text_tfidf = vectorizer.transform([text])
        
        # Make prediction using the loaded model
        prediction = model.predict(new_text_tfidf)
        predicted_probs = model.predict_proba(new_text_tfidf)
        
        # Get the sentiment (Gujarati) from the model's prediction
        sentiment = sentiment_mapping[prediction[0]]
        confidence = max(predicted_probs[0]) * 100
        
        # Return the result as JSON to be used in frontend
        return jsonify({
            'sentiment': sentiment,
            'confidence': f"{confidence:.2f}%"
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# API route - Extract keywords from the given text
@app.route('/extract_keywords', methods=['POST'])
def extract_keywords():
    try:
        # Get the text from the request (from the frontend)
        text = request.form['text']
        
        if not text:
            return jsonify({'error': 'Text is required for keyword extraction.'}), 400
        
        # Check if the text is in Gujarati
        if not is_gujarati(text):
            return jsonify({'error': 'માત્ર ગુજરાતી લખાણ લખો'}), 400
        
        # Preprocess the input text using CountVectorizer
        count_vectorizer = CountVectorizer(stop_words='english')
        words = count_vectorizer.fit_transform([text])
        
        # Extract top n words (keywords)
        keywords = count_vectorizer.get_feature_names_out()
        
        # Return the keywords
        return jsonify({'keywords': keywords.tolist()})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Run the app
if __name__ == "__main__":
    app.run(debug=True)
