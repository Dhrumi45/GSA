from flask import Flask, request, jsonify, render_template
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
import re  # To use regular expressions for Gujarati character checking

# Load the pre-trained model and vectorizer
model = joblib.load(r"C:\Users\Admin\Desktop\MY_Pro\Project\3 FM 80+ Accuracy\FM1\New folder\gujarati_sentiment_model.pkl")
vectorizer = joblib.load(r"C:\Users\Admin\Desktop\MY_Pro\Project\3 FM 80+ Accuracy\FM1\New folder\tfidf_vectorizer.pkl")

# Mapping sentiment labels (for easier understanding of results)
sentiment_mapping = {1: "સકારાત્મક", 2: "તટસ્થ", 0: "નકારાત્મક"}

# Initialize Flask app
app = Flask(__name__)

# Function to check if the text contains Gujarati characters and surrounding symbols
def is_gujarati(text):
    # Regex to check if the text contains at least one Gujarati character
    return bool(re.search(r'[\u0A80-\u0AFF]', text))

# Function to preprocess input text to allow numbers, symbols, and special characters surrounded by Gujarati text
def preprocess_text(text):
    # Remove non-Gujarati characters unless they are part of a valid Gujarati text sequence
    # This will allow numbers and symbols if surrounded by Gujarati text
    text = re.sub(r'(?<![\u0A80-\u0AFF])[^a-zA-Z0-9\u0A80-\u0AFF\s]+(?![\u0A80-\u0AFF])', '', text)  # Remove external non-Gujarati symbols
    text = ' '.join(text.split())  # Remove any extra spaces
    return text

# Home route - Display the frontend webpage
@app.route('/')
def home():
    return render_template('index.html')

# API route - Predict sentiment for given text
@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get the text from the request (from the frontend)
        text = request.form['text']
        
        if not text:
            return jsonify({'error': 'લેખન જરૂરી છે'}), 400

        # Check if the text contains at least some Gujarati characters
        if not is_gujarati(text):
            return jsonify({'error': 'માત્ર ગુજરાતી લખાણ લખો'}), 400
        
        # Preprocess the input text
        processed_text = preprocess_text(text)
        
        # Log the processed text (for debugging)
        print(f"Processed Text: {processed_text}")

        # Transform the processed text using the same vectorizer
        new_text_tfidf = vectorizer.transform([processed_text])
        
        # Make prediction using the loaded model
        prediction = model.predict(new_text_tfidf)
        predicted_probs = model.predict_proba(new_text_tfidf)
        
        # Log the prediction and probabilities (for debugging)
        print(f"Prediction: {prediction[0]}, Prediction Probabilities: {predicted_probs[0]}")

        # Get the sentiment (Gujarati) from the model's prediction
        sentiment = sentiment_mapping.get(prediction[0], "Unknown")
        confidence = max(predicted_probs[0]) * 100
        
        # Return the result as JSON to be used in frontend
        return jsonify({
            'sentiment': sentiment,
            'confidence': f"{confidence:.2f}%"
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# API route - Extract keywords from the given text
@app.route('/extract_keywords', methods=['POST'])
def extract_keywords():
    try:
        # Get the text from the request (from the frontend)
        text = request.form['text']
        
        if not text:
            return jsonify({'error': 'Text is required for keyword extraction.'}), 400
        
        # Check if the text contains at least some Gujarati characters
        if not is_gujarati(text):
            return jsonify({'error': 'માત્ર ગુજરાતી લખાણ લખો'}), 400
        
        # Preprocess the input text using CountVectorizer
        count_vectorizer = CountVectorizer(stop_words='english')
        words = count_vectorizer.fit_transform([text])
        
        # Extract top n words (keywords)
        keywords = count_vectorizer.get_feature_names_out()
        
        # Return the keywords
        return jsonify({'keywords': keywords.tolist()})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Run the app
if __name__ == "__main__":
    app.run(debug=True)
